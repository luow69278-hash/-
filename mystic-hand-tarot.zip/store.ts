import { create } from 'zustand';
import { AppState, GestureType, HandPosition } from './types';

interface AppStore {
  // Logic State
  appState: AppState;
  setAppState: (state: AppState) => void;
  
  // Interaction State
  gesture: GestureType;
  setGesture: (gesture: GestureType) => void;
  
  handPosition: HandPosition;
  setHandPosition: (pos: HandPosition) => void;
  
  // Card Logic
  focusedCardId: number | null;
  setFocusedCardId: (id: number | null) => void;
  
  // Control Mode
  isMouseMode: boolean;
  toggleMouseMode: () => void;
  
  // Wiggle Detection
  wiggleCount: number;
  incrementWiggle: () => void;
  resetWiggle: () => void;
}

export const useStore = create<AppStore>((set) => ({
  appState: AppState.STACK,
  setAppState: (state) => set({ appState: state }),
  
  gesture: GestureType.NONE,
  setGesture: (gesture) => set({ gesture }),
  
  handPosition: { x: 0, y: 0, tilt: 0 },
  setHandPosition: (pos) => set({ handPosition: pos }),
  
  focusedCardId: null,
  setFocusedCardId: (id) => set({ focusedCardId: id }),
  
  isMouseMode: false,
  toggleMouseMode: () => set((state) => ({ isMouseMode: !state.isMouseMode })),

  wiggleCount: 0,
  incrementWiggle: () => set((state) => ({ wiggleCount: state.wiggleCount + 1 })),
  resetWiggle: () => set({ wiggleCount: 0 })
}));
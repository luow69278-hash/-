import React, { useEffect } from 'react';
import { useStore } from '../store';
import { AppState, GestureType } from '../types';

export const MouseHandler: React.FC = () => {
    const isMouseMode = useStore(s => s.isMouseMode);
    const setHandPosition = useStore(s => s.setHandPosition);
    const setAppState = useStore(s => s.setAppState);
    const setGesture = useStore(s => s.setGesture);
    const setFocusedCardId = useStore(s => s.setFocusedCardId);
    const appState = useStore(s => s.appState);
    const incrementWiggle = useStore(s => s.incrementWiggle);
    const wiggleCount = useStore(s => s.wiggleCount);

    useEffect(() => {
        if (!isMouseMode) return;

        const handleMove = (e: MouseEvent) => {
            // Map 0..window -> -1..1
            const x = (e.clientX / window.innerWidth) * 2 - 1;
            const y = -(e.clientY / window.innerHeight) * 2 + 1;
            setHandPosition({ x, y, tilt: 0 });

            // Simulate Wiggle with rapid X movement if in Focused mode
            if (appState === AppState.FOCUSED) {
                 if (Math.abs(e.movementX) > 20) {
                     incrementWiggle();
                 }
            }
        };

        const handleDown = () => {
            if (appState === AppState.STACK) {
                setGesture(GestureType.OPEN_PALM);
                setAppState(AppState.SHUFFLE);
            } else if (appState === AppState.SHUFFLE) {
                setGesture(GestureType.POINTING);
                setAppState(AppState.FOCUSED);
                setFocusedCardId(Math.floor(Math.random() * 22));
            } else if (appState === AppState.REVEALED) {
                 setGesture(GestureType.FIST);
                 setAppState(AppState.STACK);
                 setFocusedCardId(null);
            }
        };

        const handleUp = () => {
             // Optional reset logic
        };

        // Reveal logic for mouse
        if (wiggleCount > 20 && appState === AppState.FOCUSED) {
            setAppState(AppState.REVEALED);
        }

        window.addEventListener('mousemove', handleMove);
        window.addEventListener('mousedown', handleDown);
        window.addEventListener('mouseup', handleUp);

        return () => {
            window.removeEventListener('mousemove', handleMove);
            window.removeEventListener('mousedown', handleDown);
            window.removeEventListener('mouseup', handleUp);
        };
    }, [isMouseMode, appState, wiggleCount, setHandPosition, setAppState, setGesture, setFocusedCardId, incrementWiggle]);

    return null;
}
import React from 'react';
import { useStore } from '../store';
import { AppState, GestureType } from '../types';

export const UIOverlay: React.FC = () => {
  const appState = useStore(s => s.appState);
  const gesture = useStore(s => s.gesture);
  const isMouseMode = useStore(s => s.isMouseMode);
  const toggleMouseMode = useStore(s => s.toggleMouseMode);
  
  // Helper to visualize state
  const getStateText = () => {
    switch (appState) {
      case AppState.STACK: return "Stack: Waiting...";
      case AppState.SHUFFLE: return "Shuffling: Move your hand";
      case AppState.FOCUSED: return "Focused: Point to select, Shake to reveal";
      case AppState.REVEALED: return "Revealed: The truth is known";
    }
  };

  const getGestureIcon = () => {
    switch(gesture) {
        case GestureType.FIST: return "✊";
        case GestureType.OPEN_PALM: return "✋";
        case GestureType.POINTING: return "☝️";
        default: return "Wait...";
    }
  }

  return (
    <div className="absolute inset-0 pointer-events-none select-none font-sans">
      {/* Header */}
      <div className="absolute top-8 left-8 text-white/80">
        <h1 className="text-3xl tracking-[0.2em] font-light uppercase text-indigo-300">Arcana</h1>
        <p className="text-xs text-indigo-400/60 mt-1">Interactive WebGL Tarot</p>
      </div>

      {/* State Indicator */}
      <div className="absolute bottom-12 left-0 right-0 text-center">
        <div className="inline-block backdrop-blur-md bg-black/30 border border-white/10 px-8 py-3 rounded-full">
            <span className="text-indigo-200 text-sm tracking-widest uppercase animate-pulse">
                {getStateText()}
            </span>
        </div>
      </div>

      {/* Gesture Debugger / Guide */}
      {!isMouseMode && (
          <div className="absolute top-8 left-1/2 -translate-x-1/2 text-white/50 text-xs flex flex-col items-center gap-2">
            <div className="text-4xl">{getGestureIcon()}</div>
            <div className="flex gap-4">
                <span>✊ Reset</span>
                <span>✋ Shuffle</span>
                <span>☝️ Pick</span>
            </div>
          </div>
      )}

      {/* Mouse Toggle */}
      <div className="absolute bottom-8 right-8 pointer-events-auto">
        <button 
          onClick={toggleMouseMode}
          className="text-white/40 hover:text-white text-xs uppercase tracking-widest border border-white/20 px-4 py-2 hover:bg-white/5 transition-all"
        >
          {isMouseMode ? "Enable Camera" : "Switch to Mouse"}
        </button>
      </div>
    </div>
  );
};
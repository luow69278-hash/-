import React, { useEffect, useRef, useState } from 'react';
import { FilesetResolver, HandLandmarker, DrawingUtils } from '@mediapipe/tasks-vision';
import { useStore } from '../store';
import { AppState, GestureType } from '../types';

export const GestureController: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [loadingStatus, setLoadingStatus] = useState<string>('Initializing...');
  const [error, setError] = useState<string>('');
  
  // Store actions
  const setGesture = useStore(s => s.setGesture);
  const setHandPosition = useStore(s => s.setHandPosition);
  const setAppState = useStore(s => s.setAppState);
  const appState = useStore(s => s.appState);
  const incrementWiggle = useStore(s => s.incrementWiggle);
  const setFocusedCardId = useStore(s => s.setFocusedCardId);
  const isMouseMode = useStore(s => s.isMouseMode);

  // Logic refs
  const handLandmarkerRef = useRef<HandLandmarker | null>(null);
  const requestRef = useRef<number>(0);
  const lastVideoTimeRef = useRef<number>(-1);
  const gestureHoldTimer = useRef<number>(0);
  const lastIndexTipX = useRef<number>(0);

  useEffect(() => {
    if (isMouseMode) {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
      cancelAnimationFrame(requestRef.current);
      return;
    }

    const init = async () => {
      try {
        setLoadingStatus('Starting Camera...');
        
        // 1. Camera
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { width: 320, height: 240, frameRate: 30 } 
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          // Ensure video is playing
          await videoRef.current.play();
        }

        // 2. MediaPipe with Matching WASM Version
        setLoadingStatus('Loading AI...');
        
        // Use a generic latest version or specific version that is known to work
        const vision = await FilesetResolver.forVisionTasks(
          "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm"
        );
        
        handLandmarkerRef.current = await HandLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
            delegate: "GPU"
          },
          runningMode: "VIDEO",
          numHands: 1
        });

        setLoadingStatus('');
        startDetectionLoop();

      } catch (err: any) {
        console.error("Init Error:", err);
        setError("Camera/AI Init Failed. Switch to Mouse Mode.");
        setLoadingStatus('Error');
      }
    };

    init();

    return () => {
      cancelAnimationFrame(requestRef.current);
      if (handLandmarkerRef.current) handLandmarkerRef.current.close();
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isMouseMode]);


  const startDetectionLoop = () => {
    const loop = () => {
        predictWebcam();
        requestRef.current = requestAnimationFrame(loop);
    };
    loop();
  };

  const predictWebcam = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const landmarker = handLandmarkerRef.current;

    // Safety checks
    if (!video || !canvas || !landmarker) return;
    if (video.readyState < 2) return; // Wait for video data

    if (video.currentTime !== lastVideoTimeRef.current) {
        lastVideoTimeRef.current = video.currentTime;
        
        const startTimeMs = performance.now();
        const results = landmarker.detectForVideo(video, startTimeMs);
        
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        ctx.save();
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        if (results.landmarks && results.landmarks.length > 0) {
            const landmarks = results.landmarks[0];
            
            // Visuals
            const drawingUtils = new DrawingUtils(ctx);
            drawingUtils.drawConnectors(landmarks, HandLandmarker.HAND_CONNECTIONS, {
                color: "rgba(200, 180, 255, 0.4)", lineWidth: 2 
            });
            drawingUtils.drawLandmarks(landmarks, { 
                color: "#d4af37", lineWidth: 1, radius: 2 
            });

            processGestures(landmarks);
        } else {
             // Lost tracking
             setGesture(GestureType.NONE);
        }
        ctx.restore();
    }
  };

  const processGestures = (landmarks: any[]) => {
    // Coordinate Mapping (Mirror)
    const palmX = landmarks[9].x;
    const palmY = landmarks[9].y;
    const normX = (palmX * -2) + 1; // 0..1 -> -1..1 (Inverted X)
    const normY = (palmY * -2) + 1;
    
    setHandPosition({ x: normX, y: normY, tilt: 0 });

    // Gesture Detection Logic
    const wrist = landmarks[0];
    const isExtended = (tipIdx: number, pipIdx: number) => {
        const tip = landmarks[tipIdx];
        const pip = landmarks[pipIdx];
        // Check if tip is further from wrist than PIP
        const dTip = Math.hypot(tip.x - wrist.x, tip.y - wrist.y);
        const dPip = Math.hypot(pip.x - wrist.x, pip.y - wrist.y);
        return dTip > dPip + 0.02; 
    };

    const indexExt = isExtended(8, 6);
    const middleExt = isExtended(12, 10);
    const ringExt = isExtended(16, 14);
    const pinkyExt = isExtended(20, 18);
    // Thumb is tricky, use simpler distance check
    const thumbExt = Math.hypot(landmarks[4].x - landmarks[17].x, landmarks[4].y - landmarks[17].y) > 0.15;

    let detected = GestureType.NONE;

    const fingerCount = [indexExt, middleExt, ringExt, pinkyExt, thumbExt].filter(Boolean).length;

    if (fingerCount <= 1) {
        // Mostly closed
        detected = GestureType.FIST;
    } else if (fingerCount === 5 || (fingerCount === 4 && !thumbExt)) {
        detected = GestureType.OPEN_PALM;
    } else if (indexExt && !middleExt && !ringExt && !pinkyExt) {
        detected = GestureType.POINTING;
    }
    
    setGesture(detected);

    // State Transitions
    const currentState = useStore.getState().appState; 
    const now = Date.now();

    // 1. FIST -> RESET
    if (detected === GestureType.FIST) {
        if (gestureHoldTimer.current === 0) gestureHoldTimer.current = now;
        if (now - gestureHoldTimer.current > 600) { 
             if (currentState !== AppState.STACK) {
                 setAppState(AppState.STACK);
                 setFocusedCardId(null);
             }
             gestureHoldTimer.current = 0;
        }
    } else {
        gestureHoldTimer.current = 0;
    }

    // 2. PALM -> SHUFFLE
    if (detected === GestureType.OPEN_PALM && currentState === AppState.STACK) {
        setAppState(AppState.SHUFFLE);
    }

    // 3. POINT -> FOCUS
    if (detected === GestureType.POINTING) {
        if (currentState === AppState.SHUFFLE) {
             setAppState(AppState.FOCUSED);
             setFocusedCardId(Math.floor(Math.random() * 22));
        }
        
        // Wiggle Detection for REVEAL
        if (currentState === AppState.FOCUSED) {
            const indexTip = landmarks[8];
            const diff = Math.abs(indexTip.x - lastIndexTipX.current);
            if (diff > 0.04) { // Sensitivity
                incrementWiggle();
                const count = useStore.getState().wiggleCount;
                if (count > 8) {
                    setAppState(AppState.REVEALED);
                }
            }
            lastIndexTipX.current = indexTip.x;
        }
    }
  };


  if (isMouseMode) return null;

  return (
    <div className="fixed top-4 right-4 z-50 transition-opacity duration-500 hover:opacity-100 opacity-80">
      <div className="relative w-[240px] h-[180px] bg-black/80 rounded-lg overflow-hidden border border-indigo-500/50 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
        <video 
          ref={videoRef}
          playsInline
          muted
          className="absolute top-0 left-0 w-full h-full object-cover transform scale-x-[-1]"
        />
        <canvas 
          ref={canvasRef}
          width={320}
          height={240}
          className="absolute top-0 left-0 w-full h-full object-cover transform scale-x-[-1] opacity-90"
        />
        
        {loadingStatus && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 z-20">
            <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mb-2"></div>
            <span className="text-[10px] text-indigo-300 uppercase tracking-widest">{loadingStatus}</span>
          </div>
        )}
        
        {error && (
            <div className="absolute inset-0 flex items-center justify-center p-2 bg-red-900/90 text-white text-[10px] text-center z-30">
                {error}
            </div>
        )}
      </div>
    </div>
  );
};
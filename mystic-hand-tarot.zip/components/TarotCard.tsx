import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useTexture } from '@react-three/drei';
import * as THREE from 'three';
import { useStore } from '../store';
import { AppState, TarotCardData } from '../types';
import './shaders';

// Constants
const CARD_WIDTH = 2;
const CARD_HEIGHT = 3.5;
const CARD_THICKNESS = 0.02;

interface TarotCardProps {
  data: TarotCardData;
  index: number;
  total: number;
}

export const TarotCard: React.FC<TarotCardProps> = ({ data, index, total }) => {
  const groupRef = useRef<THREE.Group>(null);
  const backMaterialRef = useRef<THREE.ShaderMaterial>(null);
  
  // Load texture for this card
  const texture = useTexture(data.image);
  
  const appState = useStore(s => s.appState);
  const handPosition = useStore(s => s.handPosition);
  const focusedCardId = useStore(s => s.focusedCardId);

  // Memoize random offsets
  const randomValues = useMemo(() => ({
    x: (Math.random() - 0.5) * 8, 
    y: (Math.random() - 0.5) * 5, 
    rotZ: (Math.random() - 0.5) * 0.5,
    stackRot: (Math.random() - 0.5) * 0.1
  }), []);

  useFrame((state) => {
    if (!groupRef.current) return;

    // Update Shader Time
    if (backMaterialRef.current) {
      backMaterialRef.current.uniforms.uTime.value = state.clock.elapsedTime;
    }

    const targetPos = new THREE.Vector3();
    const targetRot = new THREE.Euler();
    const targetScale = new THREE.Vector3(1, 1, 1);
    
    // --- STATE MACHINE ---
    
    if (appState === AppState.STACK) {
        // Stacked in center
        targetPos.set(
            0,
            0,
            index * 0.008 
        );
        targetRot.set(0, 0, randomValues.stackRot);
    } 
    else if (appState === AppState.SHUFFLE) {
        // Follow hand
        targetPos.set(
            (handPosition.x * 6) + randomValues.x * 0.5,
            (handPosition.y * 4) + randomValues.y * 0.5,
            index * 0.02 + Math.sin(state.clock.elapsedTime * 2 + index) * 0.2
        );
        targetRot.set(
            handPosition.y * 0.5,
            handPosition.x * 0.5,
            randomValues.rotZ + handPosition.x
        );
    } 
    else if (appState === AppState.FOCUSED) {
        if (focusedCardId === data.id) {
            // Selected Card
            targetPos.set(0, 0, 3.8);
            targetRot.set(0, 0, 0);
            targetPos.y += Math.sin(state.clock.elapsedTime * 1.5) * 0.2;
            targetScale.set(1.2, 1.2, 1.2);
        } else {
            // Background Cards
            targetPos.set(randomValues.x * 2.5, randomValues.y * 2.5, -4);
            targetRot.set(0, 0, randomValues.rotZ);
            targetScale.set(0.6, 0.6, 0.6);
        }
    } 
    else if (appState === AppState.REVEALED) {
        if (focusedCardId === data.id) {
            targetPos.set(0, 0, 4.2);
            targetRot.set(0, Math.PI, 0); // Flip to show face
            targetScale.set(1.6, 1.6, 1.6);
        } else {
             targetPos.set(randomValues.x * 2.5, randomValues.y * 2.5, -4);
             targetScale.set(0.6, 0.6, 0.6);
        }
    }

    // --- ANIMATION LERP ---
    const smooth = 0.1;
    
    groupRef.current.position.lerp(targetPos, smooth);
    groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, targetRot.x, smooth);
    groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, targetRot.y, smooth);
    groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, targetRot.z, smooth);
    
    groupRef.current.scale.lerp(targetScale, smooth);
  });

  return (
    <group ref={groupRef}>
        {/* Card Body (Side edges) */}
        <mesh castShadow receiveShadow>
            <boxGeometry args={[CARD_WIDTH, CARD_HEIGHT, CARD_THICKNESS]} />
            <meshStandardMaterial color="#1a1a2e" roughness={0.3} metalness={0.8} />
            {/* Added a subtle rim color via color logic not straightforward on standard material, relying on lights */}
        </mesh>

        {/* Card Back - Shader */}
        <mesh position={[0, 0, CARD_THICKNESS/2 + 0.001]}>
            <planeGeometry args={[CARD_WIDTH * 0.95, CARD_HEIGHT * 0.95]} />
            <cardBackMaterial ref={backMaterialRef} transparent />
        </mesh>

        {/* Card Front - Content */}
        <group rotation={[0, Math.PI, 0]} position={[0, 0, -CARD_THICKNESS/2 - 0.001]}>
             {/* Main Texture */}
             <mesh>
                <planeGeometry args={[CARD_WIDTH, CARD_HEIGHT]} />
                <meshStandardMaterial 
                    map={texture} 
                    roughness={0.2}  // Low roughness for "mirror" reflection
                    metalness={0.1} 
                    color="#ffffff"
                />
             </mesh>
             
             {/* Border Detail Overlay (Optional, simple frame) */}
             <mesh position={[0, 0, 0.001]} rotation={[0, 0, Math.PI/4]}>
                 <ringGeometry args={[CARD_WIDTH * 0.49, CARD_WIDTH * 0.5, 4]} />
                 <meshBasicMaterial color="#d4af37" />
             </mesh>
        </group>
        
        {/* Particles */}
        {appState === AppState.FOCUSED && focusedCardId === data.id && <CardParticles />}
    </group>
  );
};

const CardParticles = () => {
    const count = 40;
    const mesh = useRef<THREE.Points>(null);
    const mat = useRef<THREE.ShaderMaterial>(null);
    
    const [positions, randomness] = useMemo(() => {
        const pos = new Float32Array(count * 3);
        const rand = new Float32Array(count);
        for(let i=0; i<count; i++) {
            pos[i*3] = (Math.random()-0.5) * 3;
            pos[i*3+1] = (Math.random()-0.5) * 5;
            pos[i*3+2] = (Math.random()-0.5) * 2;
            rand[i] = Math.random();
        }
        return [pos, rand];
    }, []);

    useFrame((state) => {
        if (mat.current) mat.current.uniforms.uTime.value = state.clock.elapsedTime;
        if (mesh.current) mesh.current.rotation.y += 0.01;
    });

    return (
        <points ref={mesh}>
            <bufferGeometry>
                <bufferAttribute attach="attributes-position" count={count} array={positions} itemSize={3} />
                <bufferAttribute attach="attributes-aScale" count={count} array={randomness} itemSize={1} />
                <bufferAttribute attach="attributes-aVelocity" count={count} array={positions} itemSize={3} /> 
            </bufferGeometry>
            <particleMaterial ref={mat} transparent depthWrite={false} blending={THREE.AdditiveBlending} />
        </points>
    );
};

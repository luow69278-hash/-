import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { EffectComposer, Bloom, Noise, Vignette } from '@react-three/postprocessing';
import { Deck } from './Deck';
import { PerspectiveCamera } from '@react-three/drei';
// Import shaders to register them
import './shaders';

export const Scene: React.FC = () => {
  return (
    <div className="w-full h-full bg-[#050208]">
      <Canvas dpr={[1, 2]} gl={{ antialias: false, alpha: false, powerPreference: "high-performance" }}>
        <PerspectiveCamera makeDefault position={[0, 0, 14]} fov={40} />
        
        <color attach="background" args={['#050208']} />
        
        {/* Cinematic Lighting */}
        <ambientLight intensity={0.4} />
        <pointLight position={[10, 5, 5]} intensity={2} color="#a020f0" distance={20} />
        <pointLight position={[-10, -5, 5]} intensity={1.5} color="#d4af37" distance={20} />
        
        <spotLight 
          position={[0, 10, 2]} 
          intensity={5} 
          color="#5040aa" 
          angle={0.6} 
          penumbra={0.5} 
          castShadow 
        />

        <Suspense fallback={null}>
          <Deck />
        </Suspense>

        <EffectComposer enableNormalPass={false}>
          <Bloom luminanceThreshold={0.4} mipmapBlur intensity={1.5} radius={0.4} />
          <Noise opacity={0.08} />
          <Vignette eskil={false} offset={0.1} darkness={1.1} />
        </EffectComposer>
      </Canvas>
    </div>
  );
};
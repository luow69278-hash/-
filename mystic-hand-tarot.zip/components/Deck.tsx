import React from 'react';
import { TarotCard } from './TarotCard';
import { TAROT_DECK } from '../types';

export const Deck: React.FC = () => {
  return (
    <group>
      {TAROT_DECK.map((card, index) => (
        <TarotCard 
          key={card.id} 
          data={card} 
          index={index} 
          total={TAROT_DECK.length} 
        />
      ))}
    </group>
  );
};
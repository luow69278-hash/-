import React from 'react';
import { Scene } from './components/Scene';
import { GestureController } from './components/GestureController';
import { UIOverlay } from './components/UIOverlay';
import { MouseHandler } from './components/MouseHandler';

const App: React.FC = () => {
  return (
    <main className="relative w-full h-full">
      <Scene />
      <GestureController />
      <MouseHandler />
      <UIOverlay />
    </main>
  );
};

export default App;
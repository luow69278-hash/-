export enum AppState {
  STACK = 'STACK',
  SHUFFLE = 'SHUFFLE',
  FOCUSED = 'FOCUSED',
  REVEALED = 'REVEALED'
}

export enum GestureType {
  NONE = 'NONE',
  FIST = 'FIST',
  OPEN_PALM = 'OPEN_PALM',
  POINTING = 'POINTING',
  VICTORY = 'VICTORY' // Optional, not used in logic but good for debugging
}

export interface HandPosition {
  x: number; // Normalized -1 to 1
  y: number; // Normalized -1 to 1
  tilt: number; // Rotation in radians
}

export interface TarotCardData {
  id: number;
  name: string;
  arcana: string;
  image: string;
}

export const TAROT_DECK: TarotCardData[] = [
  { 
    id: 0, 
    name: "The Fool", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/RWS_Tarot_00_Fool.jpg/300px-RWS_Tarot_00_Fool.jpg"
  },
  { 
    id: 1, 
    name: "The Magician", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/RWS_Tarot_01_Magician.jpg/300px-RWS_Tarot_01_Magician.jpg"
  },
  { 
    id: 2, 
    name: "The High Priestess", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/RWS_Tarot_02_High_Priestess.jpg/300px-RWS_Tarot_02_High_Priestess.jpg"
  },
  { 
    id: 3, 
    name: "The Empress", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d2/RWS_Tarot_03_Empress.jpg/300px-RWS_Tarot_03_Empress.jpg"
  },
  { 
    id: 4, 
    name: "The Emperor", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/RWS_Tarot_04_Emperor.jpg/300px-RWS_Tarot_04_Emperor.jpg"
  },
  { 
    id: 5, 
    name: "The Hierophant", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/RWS_Tarot_05_Hierophant.jpg/300px-RWS_Tarot_05_Hierophant.jpg"
  },
  { 
    id: 6, 
    name: "The Lovers", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/RWS_Tarot_06_Lovers.jpg/300px-RWS_Tarot_06_Lovers.jpg"
  },
  { 
    id: 7, 
    name: "The Chariot", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/RWS_Tarot_07_Chariot.jpg/300px-RWS_Tarot_07_Chariot.jpg"
  },
  { 
    id: 8, 
    name: "Strength", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/RWS_Tarot_08_Strength.jpg/300px-RWS_Tarot_08_Strength.jpg"
  },
  { 
    id: 9, 
    name: "The Hermit", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/RWS_Tarot_09_Hermit.jpg/300px-RWS_Tarot_09_Hermit.jpg"
  },
  { 
    id: 10, 
    name: "Wheel of Fortune", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/RWS_Tarot_10_Wheel_of_Fortune.jpg/300px-RWS_Tarot_10_Wheel_of_Fortune.jpg"
  },
  { 
    id: 11, 
    name: "Justice", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e0/RWS_Tarot_11_Justice.jpg/300px-RWS_Tarot_11_Justice.jpg"
  },
  { 
    id: 12, 
    name: "The Hanged Man", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/RWS_Tarot_12_Hanged_Man.jpg/300px-RWS_Tarot_12_Hanged_Man.jpg"
  },
  { 
    id: 13, 
    name: "Death", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/RWS_Tarot_13_Death.jpg/300px-RWS_Tarot_13_Death.jpg"
  },
  { 
    id: 14, 
    name: "Temperance", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/RWS_Tarot_14_Temperance.jpg/300px-RWS_Tarot_14_Temperance.jpg"
  },
  { 
    id: 15, 
    name: "The Devil", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/RWS_Tarot_15_Devil.jpg/300px-RWS_Tarot_15_Devil.jpg"
  },
  { 
    id: 16, 
    name: "The Tower", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/RWS_Tarot_16_Tower.jpg/300px-RWS_Tarot_16_Tower.jpg"
  },
  { 
    id: 17, 
    name: "The Star", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/RWS_Tarot_17_Star.jpg/300px-RWS_Tarot_17_Star.jpg"
  },
  { 
    id: 18, 
    name: "The Moon", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/RWS_Tarot_18_Moon.jpg/300px-RWS_Tarot_18_Moon.jpg"
  },
  { 
    id: 19, 
    name: "The Sun", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/RWS_Tarot_19_Sun.jpg/300px-RWS_Tarot_19_Sun.jpg"
  },
  { 
    id: 20, 
    name: "Judgement", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/RWS_Tarot_20_Judgement.jpg/300px-RWS_Tarot_20_Judgement.jpg"
  },
  { 
    id: 21, 
    name: "The World", 
    arcana: "Major",
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/RWS_Tarot_21_World.jpg/300px-RWS_Tarot_21_World.jpg"
  }
];